from sets import Set
import uuid
import time
import json
import requests
from decimal import Decimal
import database

class Client(object):
    def __init__(self, url, public_key, secret):
        self.url = url + "/api/2"
        self.session = requests.session()
        self.session.auth = (public_key, secret)

    def get_symbol(self, symbol_code):
        """Get symbol."""
        return self.session.get("%s/public/symbol/%s" % (self.url, symbol_code)).json()

    def get_orderbook(self, symbol_code):
        """Get orderbook. """
        return self.session.get("%s/public/orderbook/%s" % (self.url, symbol_code)).json()

    def get_address(self, currency_code):
        """Get address for deposit."""
        return self.session.get("%s/account/crypto/address/%s" % (self.url, currency_code)).json()

    def get_account_balance(self):
        """Get main balance."""
        return self.session.get("%s/account/balance" % self.url).json()

    def get_trading_balance(self):
        """Get trading balance."""
        return self.session.get("%s/trading/balance" % self.url).json()

    def transfer(self, currency_code, amount, to_exchange):
        return self.session.post("%s/account/transfer" % self.url, data={
                'currency': currency_code, 'amount': amount,
                'type': 'bankToExchange' if to_exchange else 'exchangeToBank'
            }).json()

    def new_order(self, client_order_id, symbol_code, side,limit, quantity, price=None):
        """Place an order."""
        data = {'symbol': symbol_code, 'side': side, 'limit':limit,'quantity': quantity}

        if price is not None:
            data['price'] = price

        return self.session.put("%s/order/%s" % (self.url, client_order_id), data=data).json()

    def get_active_order(self, client_order_id, wait=None):
        """Get order info."""
        data = {'wait': wait} if wait is not None else {}

        return self.session.get("%s/order/%s" % (self.url, client_order_id), params=data).json()
    
    def get_active_orderlist(self):
        
        return self.session.get("%s/order/" % (self.url)).json()
        
    def cancel_order(self, client_order_id):
        """Cancel order."""
        return self.session.delete("%s/order/%s" % (self.url, client_order_id)).json()
    def ticker(self):
        return self.session.get("%s/public/ticker/"%(self.url)).json()
    
    def trades(self,symbol="BCNBTC"):
        
        return self.session.get("%s/public/trades/%s"%(self.url,symbol)).json()
    
    def withdraw(self, currency_code, amount, address, network_fee=None):
        """Withdraw."""
        data = {'currency': currency_code, 'amount': amount, 'address': address}

        if network_fee is not None:
            data['networkfee'] = network_fee

        return self.session.post("%s/account/crypto/withdraw" % self.url, data=data).json()

    def get_transaction(self, transaction_id):
        """Get transaction info."""
        return self.session.get("%s/account/transactions/%s" % (self.url, transaction_id)).json()




public_key = "7459382724489f8e8f62e7210dc902a4"
secret = "2850ed11b8922a28f2993b6b673782b7"
client = Client("https://api.hitbtc.com", public_key, secret)

'''
helpful functions
'''


# buy function to buy BCN
def buy(coin,amount=100):
    return client.new_order(uuid.uuid4().hex, "BCNBTC", "buy",coin, amount, coin)

# sell function to sell BCN 
def sell(coin,amount=100):
    return client.new_order(uuid.uuid4().hex, "BCNBTC", "sell",coin, amount, coin)




def buy_ability(my_balance_btc,current_price,amount=100):
        
    total_btc_price=current_price*amount

    fee=0.001*total_btc_price

    total_btc_price+=fee

    if my_balance_btc>total_btc_price:
        return True
    else:
        return False



def sell_ability(my_balance_bcn,amount=100):
    return my_balance_bcn>amount or my_balance_bcn==amount



#helpful functions finished


'''
    Two sets active_buy_order and buy_order_database
'''


active_buy_order=Set()
buy_order_address=Set()


active_order=client.get_active_orderlist()

for order in active_order:
    if order["side"]=="buy":
        tpl=(order['clientOrderId'],order['price'])
        active_buy_order.add(tpl)


for order_from_db in database.all_stocks():
    tpl=(order_from_db[1],order_from_db[2])
    buy_order_address.add(tpl)



active_buy_order=active_buy_order-buy_order_address

if len(active_buy_order)>0:
    for x in active_buy_order:
        database.insert( x[0],x[1])


''' if I want to stop buying and selling '''
END=False

#previous ticker
previous_ticker=0
while True:
    
    '''
    set profit amount of each trades
    and 
    set amount of bcn for trading
    '''
    
    
    profit=0.0000001000

    amount=100 # Bytecoin


    
    #getting last ticker
    ticker=client.ticker()[0]
    current_ticker=ticker['last']

    increment=(profit+ previous_ticker*0.001)/amount

    #print "Buy price:"+format(previous_ticker-increment,'.10f')+" Sell Price:"+format(previous_ticker+increment,'.10f')

    if previous_ticker==0:
        previous_ticker=float(current_ticker)
    
    #bellow proceedure fetch both balances (BTC and BCN)
    btc_balance=0
    bcn_balance=0
    
    balances = client.get_trading_balance()

    # BTC Balance....
    for balance in balances:
        if balance['currency'] == 'BTC':
            btc_balance = float(balance['available'])
    
    
    
    #print('Current BTC balance: %s' %format( btc_balance,'.10f'))
    # BCN Balance
    for balance in balances:
        if balance['currency'] == 'BCN':
            bcn_balance = float(balance['available'])
    #print('Current BCN balance: %s' %bcn_balance)
    
    # balance fetching is finished
    
    
    ''' bellow procedure start from here'''
    
    
    btc_amount_requirement=buy_ability(btc_balance,float(current_ticker), amount)

    #print "Previous Ticker:"+format(previous_ticker,'.10f')+" Current Ticker:"+current_ticker
    
    if btc_amount_requirement==True and END==False and previous_ticker>float(current_ticker) :
        previous_ticker=float(current_ticker)

        buying_price=format(previous_ticker-increment,'.10f')
        status=buy(buying_price, amount)
        
        try:
            database.insert(status["clientOrderId"],current_ticker)
            
            #print "bought:"+status["clientOrderId"]+"  "+status["price"]
        except KeyError:
            print "Error occured with buy!!"
        #buy some coin and submit to db
    
     
    ''' buy procedured is finished here'''
    
    
    
    ''' sell procedure start from bellow'''
    lazy_stocks=[]
    for x in database.waiting_stocks():
        '''buy price of hundread fromd database '''
        buy_price_of_hundred=float(x[2])
        
        if sell_ability(bcn_balance, amount)==True:
            selling_price=buy_price_of_hundred+increment
            selling_price=format(selling_price,'.10f')
            status=sell(selling_price, amount)
            try:
            	#print "Sold :"+status["clientOrderId"]+"  "+status["price"]
            	lazy_stocks.append(x[1])
            except KeyError:
            	pass
    
    
    
    for i in lazy_stocks:        
        
        database.order_submitted(i)
        
        
    
    ''' sell procedure finished here '''
    
    
    
    
    '''
    when active buy list is empty
    bellow procedure will delelte all of the rows with status 1
    '''
    order_list=client.get_active_orderlist()
    bought_order_list=[]
    for data in order_list:
        bought_order_list.append(data)
    
    if len(bought_order_list)==0:
        #delete all status 1
        database.delete()
    print '.... working!'
    

    
