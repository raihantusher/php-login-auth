import sqlite3 as lite
import sys
import uuid
con = None
DATABASE_NAME="stocks.db"

def insert(clientOrderId,amount):
    '''insert on database'''
    conn=lite.connect(DATABASE_NAME)
    
    
    c = conn.cursor()
    
    
    c.execute("insert into stock('clientOrderId','buy_amount','status') values ('"+clientOrderId+"','"+amount+"',0)")
    
    # Save (commit) the changes
    conn.commit()
    
    # We can also close the connection if we are done with it.
    # Just be sure any changes have been committed or they will be lost.
    conn.close()

def delete():
    '''delete from database according to clientOrderId or amount'''
    conn=lite.connect(DATABASE_NAME)
    
    
    c = conn.cursor()
    
    c.execute("DELETE FROM stock WHERE status=1")
   
    # Save (commit) the changes
    conn.commit()
    
    # We can also close the connection if we are done with it.
    # Just be sure any changes have been committed or they will be lost.
    conn.close()



def all_stocks():
    ''' return all buys record from database'''
    conn=lite.connect(DATABASE_NAME)
    
    
    c = conn.cursor()
    tupple=c.execute('SELECT * FROM stock')
    conn.commit()
    
    return tupple

def waiting_stocks():
    ''' return all buys record from database'''
    conn=lite.connect(DATABASE_NAME)
    
    
    c = conn.cursor()
    tupple=c.execute('SELECT * FROM stock where status=0')
    conn.commit()
    
    return tupple

def order_submitted(clientOrderId):
    ''' return all buys record from database'''
    conn=lite.connect(DATABASE_NAME)
    c = conn.cursor()
    c.execute("UPDATE stock SET status=1 where clientOrderId='"+clientOrderId+"'")
    
    conn.commit()
    conn.close()

